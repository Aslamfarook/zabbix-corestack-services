ps aux | grep -w "/usr/local/bin/python2.7 /opt/core/resource_inventory/bin/resource_inventory" |grep -v grep | awk {'print $4'}
