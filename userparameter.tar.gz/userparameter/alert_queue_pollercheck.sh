#!/bin/bash




# Log validation
#logstat1=`sed -nr '/.*(SMTPAuthenticationError).*/p' /var/log/corestack/account_subscription_create.log 2>/dev/null`
#logstat1=`sed -nr '/.*(error).*/p' /var/log/corestack/alert_queue_poller.log 2>/dev/null`
#if [[ "$logstat1" == "" ]]
#then
#logstat=1
#echo "Detected NO errors in alert_queue_poller logs" >> /var/tmp/.alert_queue_poller_check
#else
#logstat=0
#echo "Detected errors in alert_queue_poller logs" >> /var/tmp/.alert_queue_poller_check
#fi

# Service validation
pstat=`ps -ef|grep -i alert_queue_poller.py|grep -v grep`
if [[ "$pstat" != "" ]]
then
psstat=1
echo "alert_queue_poller daemon is running" >> /var/tmp/.alert_queue_poller_check
else
psstat=0
echo "alert_queue_poller daemon not running" >> /var/tmp/.alert_queue_poller_check
fi

## Final validation
#if [[ $logstat -eq 0 || $psstat -eq 0 ]]
if [[ $psstat -eq 0 ]]
then
echo 0
else
echo 1
fi
