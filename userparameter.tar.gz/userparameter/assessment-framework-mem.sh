ps aux | grep -w assessment_framework.py |grep -v grep | awk {'print $4'}
