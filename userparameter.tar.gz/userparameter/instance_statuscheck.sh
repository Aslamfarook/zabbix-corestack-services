#!/bin/bash




# Log validation
#logstat1=`sed -nr '/.*(SMTPAuthenticationError).*/p' /var/log/corestack/account_subscription_create.log 2>/dev/null`
#logstat1=`sed -nr '/.*(error).*/p' /var/log/corestack/instance_status.log 2>/dev/null`
#if [[ "$logstat1" == "" ]]
#then
#logstat=1
#echo "Detected NO errors in instance_status_daemon logs" >> /var/tmp/.instance_status_check
#else
#logstat=0
#echo "Detected errors in instance_status_daemon logs" >> /var/tmp/.instance_status_check
#fi

# Service validation
pstat=`ps -ef|grep -i instance_status_daemon.py|grep -v grep`
if [[ "$pstat" != "" ]]
then
psstat=1
echo "instance_status daemon is running" >> /var/tmp/.instance_status_check
else
psstat=0
echo "instance_status daemon not running" >> /var/tmp/.instance_status_check
fi

## Final validation
if [[ $psstat -eq 0 ]]
then
echo 0
else
echo 1
fi	
