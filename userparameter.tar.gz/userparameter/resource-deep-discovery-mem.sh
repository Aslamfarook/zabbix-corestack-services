ps aux | grep -w resource_deep_discovery |grep -v grep | awk {'print $4'}
