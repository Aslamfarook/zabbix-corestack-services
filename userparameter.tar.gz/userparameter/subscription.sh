#!/bin/bash





# Connection validation

port=18085

host=localhost

timeout 3 bash -c "cat < /dev/null > /dev/tcp/$host/$port" 2>/dev/null

check=$?

echo "Connection status to $host:$port is $check" >> /var/tmp/.subscription

if [ $check -eq 0 ]

then

connstat=1

else

connstat=0

fi



# Log validation

#logstat1=`sed -nr '/.*(SMTPAuthenticationError).*/p' /var/log/corestack/notification_service.log 2>/dev/null`

#logstat1=`sed -nr '/.*(Error).*/p' /var/log/corestack/notification_service.log 2>/dev/null`

#logstat1=grep -inr error /var/log/corestack/subscription.log 2>/dev/null
#
#if [[ "$logstat1" == "" ]]
#
#then
#
#logstat=1
#
#echo "Detected NO errors in subscription logs" >> /var/tmp/.subscription
#
#else
#
#logstat=0
#
#echo "Detected errors in subscription logs" >> /var/tmp/.subscription
#
#fi	
#


# Service validation

pstat=`ps -ef|grep -i subscription|grep -v grep`

if [[ "$pstat" != "" ]]

then

psstat=1

echo "subscription Service is running" >> /var/tmp/.subscription

else

psstat=0

echo "subscription is not running" >> /var/tmp/.subscription

fi



## Final validation

if [[ $connstat -eq 0 || $psstat -eq 0 ]]

then

echo 0

else

echo 1

fi
