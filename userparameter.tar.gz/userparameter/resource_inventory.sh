#!/bin/bash





# Connection validation

port=18087

host=localhost

timeout 3 bash -c "cat < /dev/null > /dev/tcp/$host/$port" 2>/dev/null

check=$?

echo "Connection status to $host:$port is $check" >> /var/tmp/.resource_inventory_service

if [ $check -eq 0 ]

then

connstat=1

else

connstat=0

fi



# Log validation

#logstat1=grep -inr error /var/log/corestack/resource_inventory.log 2>/dev/null
#
#if [[ "$logstat1" == "" ]]
#
#then
#
#logstat=1
#
#echo "Detected NO errors in resource_inventory_service logs" >> /var/tmp/.resource_inventory_service
#
#else
#
#logstat=0
#
#echo "Detected errors in resource_inventory_service logs" >> /var/tmp/.resource_inventory_service
#
#fi	
#


# Service validation

pstat=`ps -ef|grep -i resource_inventory|grep -v grep`

if [[ "$pstat" != "" ]]

then

psstat=1

echo "resource_inventory_service Service is running" >> /var/tmp/.resource_inventory_service

else

psstat=0

echo "resource_inventory_service is not running" >> /var/tmp/.resource_inventory_service

fi



## Final validation

#if [[ $connstat -eq 0 || $logstat -eq 0 || $psstat -eq 0 ]]
if [[ $connstat -eq 0 || $psstat -eq 0 ]]

then

echo 0

else

echo 1

fi
