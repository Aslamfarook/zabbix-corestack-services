ps aux | grep -w "/usr/local/bin/python2.7 /opt/core/corestack_identity/bin/corestack-identity" |grep -v grep | awk {'print $4'}
