ps aux | grep -w access_governance_daemon.py |grep -v grep | awk {'print $4'}
