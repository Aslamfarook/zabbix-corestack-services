ps aux | grep -w operations_governance_bot.py |grep -v grep | awk {'print $4'}
