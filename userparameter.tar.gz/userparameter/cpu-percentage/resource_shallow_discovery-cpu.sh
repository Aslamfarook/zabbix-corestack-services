ps aux | grep -w "/usr/local/bin/python2.7 /opt/core/resource_inventory/bin/resource_shallow_discovery" |grep -v grep | awk {'print $3'}
