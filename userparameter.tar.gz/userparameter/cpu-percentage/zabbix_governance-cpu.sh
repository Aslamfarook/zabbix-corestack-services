ps aux | grep -w zabbix_governance.py |grep -v grep | awk {'print $3'}
