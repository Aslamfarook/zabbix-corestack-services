ps aux | grep -w resource_dependency_sync |grep -v grep | awk {'print $3'}
