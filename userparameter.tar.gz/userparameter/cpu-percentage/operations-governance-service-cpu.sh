ps aux | grep -w operations_governance_service |grep -v grep | awk {'print $3'}
