#!/bin/bash

varfile=/etc/notification/notification.conf

getval()
{
  section="$1"
  param="$2"
  found=false
  while read line
  do
    [[ $found == false && "$line" != "[$section]" ]] &&  continue
    [[ $found == true && "${line:0:1}" = '[' ]] && break
    found=true
    [[ "${line% =*}" == "$param" ]] || [[ "${line%=*}" == "$param" ]] && { echo "${line#*=}"; break; }
  done
}

# Configuration validation
user=`getval smtp username < $varfile|xargs`
host=`getval smtp smtp < $varfile|xargs`
port=`getval smtp port < $varfile|xargs`
ttls=`getval smtp enable_starttls < $varfile|xargs`
if [[ "$user" == "Internal.notifications@corestack.io" && "$host" == "smtp.office365.com" && "$port" == "587" && "$ttls" == "true" ]]
then
echo "Config is correct" > /var/tmp/.smtp_check
confstat=1
else
echo "Config is incorrect" > /var/tmp/.smtp_check
confstat=0
fi

# Connection validation
smtpport=`sed -n '/smtp/,$p' /etc/notification/notification.conf|sed -nr '/.*(port).*=.*/p'|awk -F= '{print $NF}'|xargs`
smtphost=`sed -nr '/.*(smtp).*=.*/p' /etc/notification/notification.conf|awk -F= '{print $NF}'|xargs`
timeout 3 bash -c "cat < /dev/null > /dev/tcp/$smtphost/$smtpport" 2>/dev/null
check=$?
echo "Connection status to $smtphost:$smtpport is $check" >> /var/tmp/.smtp_check
if [ $check -eq 0 ]
then
connstat=1
else
connstat=0
fi

# Log validation
#logstat1=`sed -nr '/.*(SMTPAuthenticationError).*/p' /var/log/corestack/notification_service.log 2>/dev/null`
#logstat2=`sed -nr '/.*(error).*/p' /var/log/corestack/notification.log 2>/dev/null`
#if [[ "$logstat1" == "" && "$logstat2" == "" ]]
#then
#logstat=1
#echo "Detected NO errors in notification logs" >> /var/tmp/.smtp_check
#else
#logstat=0
#echo "Detected errors in notification logs" >> /var/tmp/.smtp_check
#fi

# Service validation
pstat=`ps -ef|grep -i notify_daemon.py|grep -v grep`
if [[ "$pstat" != "" ]]
then
psstat=1
echo "Notification daemon is running" >> /var/tmp/.smtp_check
else
psstat=0
echo "Notification daemon not running" >> /var/tmp/.smtp_check
fi

## Final validation
#if [[ $confstat -eq 0 || $connstat -eq 0 || $logstat -eq 0 || $psstat -eq 0 ]]
if [[ $confstat -eq 0 || $connstat -eq 0 || $psstat -eq 0 ]]
then
echo 0
else
echo 1
fi
