#!/bin/bash



# Log validation
#logstat1=`sed -nr '/.*(SMTPAuthenticationError).*/p' /var/log/corestack/notification_service.log 2>/dev/null`
#logstat1=`sed -nr '/.*(Error).*/p' /var/log/corestack/servicenow_broker.log 2>/dev/null`
#logstat1=grep -inr error /var/log/corestack/congress.log 2>/dev/null
#if [[ "$logstat1" == "" ]]
#then
#logstat=1
#echo "Detected NO errors in congress logs" >> /var/tmp/.congress_check
#else
#logstat=0
#echo "Detected errors in congress logs" >> /var/tmp/.congress_check
#fi	

# Service validation
pstat=`ps -ef|grep -i operations_governance_bot.py|grep -v grep`
if [[ "$pstat" != "" ]]
then
psstat=1
echo "operations_governance_bot is running" >> /var/tmp/.operations_governance_bot_check
else
psstat=0
echo "operations_governance_bot is not running" >> /var/tmp/.operations_governance_bot_check
fi

## Final validation
#if [[ $connstat -eq 0 || $logstat -eq 0 || $psstat -eq 0 ]]
if [[ $psstat -eq 0 ]]
then
echo 0
else
echo 1
fi
