ps aux | grep -w alert_queue_poller.py |grep -v grep | awk {'print $4'}
