#!/bin/bash

# Log validation

#logstat1=`sed -nr '/.*(SMTPAuthenticationError).*/p' /var/log/corestack/tenant_master_subscription_status.log 2>/dev/null`

#logstat1=`sed -nr '/.*(error).*/p' /var/log/corestack/tenant_master_subscription_status.log 2>/dev/null`
#
#if [[ "$logstat1" == "" ]]
#
#then
#
#logstat=1
#
#echo "Detected NO errors in tenant_master_subscription_status logs" >> /var/tmp/.tenant_master_subscription_status_check
#
#else
#
#logstat=0
#
#echo "Detected errors in tenant_master_subscription_status logs" >> /var/tmp/.tenant_master_subscription_status_check
#
#fi



# Service validation

pstat=`ps -ef|grep -i tenant_master_subscription_status.py|grep -v grep`

if [[ "$pstat" != "" ]]

then

psstat=1

echo "tenant_master_subscription_status daemon is running" >> /var/tmp/.tenant_master_subscription_status_check

else

psstat=0

echo "tenant_master_subscription_status daemon not running" >> /var/tmp/.tenant_master_subscription_status_check

fi



## Final validation

#if [[ $logstat -eq 0 || $psstat -eq 0 ]]
if [[ $psstat -eq 0 ]]

then

echo 0

else

echo 1

fi
