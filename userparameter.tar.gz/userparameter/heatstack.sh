#!/bin/bash


# Connection validation
port=18080
host=localhost
timeout 3 bash -c "cat < /dev/null > /dev/tcp/$host/$port" 2>/dev/null
check=$?
echo "Connection status to $host:$port is $check" >> /var/tmp/.heatstack_check
if [ $check -eq 0 ]
then
connstat=1
else
connstat=0
fi

# Log validation
#logstat1=grep -inr error /var/log/corestack/heatstack.log 2>/dev/null
#if [[ "$logstat1" == "" ]]
#then
#logstat=1
#echo "Detected NO errors in Heatstack logs" >> /var/tmp/.heatstack_check
#else
#logstat=0
#echo "Detected errors in Heatstack" >> /var/tmp/.heatstack_check
#fi	

# Service validation
pstat=`ps -ef|grep -i heat-stack|grep -v grep`
if [[ "$pstat" != "" ]]
then
psstat=1
echo "Heatstack Service is running" >> /var/tmp/.heatstack_check
else
psstat=0
echo "Heatstack Service is not running" >> /var/tmp/.heatstack_check
fi

## Final validation
if [[ $connstat -eq 0 || $psstat -eq 0 ]]
then
echo 0
else
echo 1
fi
