#!/bin/bash




# Log validation
#logstat1=`sed -nr '/.*(SMTPAuthenticationError).*/p' /var/log/corestack/account_subscription_create.log 2>/dev/null`
#logstat1=`sed -nr '/.*(error).*/p' /var/log/corestack/governance_daemon.log 2>/dev/null`
#if [[ "$logstat1" == "" ]]
#then
#logstat=1
#echo "Detected NO errors in governance_daemon logs" >> /var/tmp/.governance_daemon_check
#else
#logstat=0
#echo "Detected errors in governance_daemon logs" >> /var/tmp/.governance_daemon_check
#fi

# Service validation
pstat=`ps -ef|grep -i governance_validation_daemon.py|grep -v grep`
if [[ "$pstat" != "" ]]
then
psstat=1
echo "governance_validation_daemon is running" >> /var/tmp/.governance_validation_daemon_check
else
psstat=0
echo "governance_validation_daemon not running" >> /var/tmp/.governance_validation_daemon_check
fi

## Final validation
if [[ $psstat -eq 0 ]]
then
echo 0
else
echo 1
fi	
