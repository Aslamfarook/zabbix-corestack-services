ps aux | grep -w cloudops_daemon.py |grep -v grep | awk {'print $3'}
