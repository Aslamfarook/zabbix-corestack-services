ps aux | grep -w request_updator.py |grep -v grep | awk {'print $3'}
