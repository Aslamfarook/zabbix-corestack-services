ps aux | grep -w finance_daemon |grep -v grep | awk {'print $3'}
