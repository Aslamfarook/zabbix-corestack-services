ps aux | grep -w metrics_to_anomalydetection_daemon.py |grep -v grep | awk {'print $4'}
