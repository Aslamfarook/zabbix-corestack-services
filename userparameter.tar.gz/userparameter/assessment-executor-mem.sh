ps aux | grep -w assessment_executor.py |grep -v grep | awk {'print $4'}
