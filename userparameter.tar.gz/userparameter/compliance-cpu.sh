ps aux | grep -w compliance.py |grep -v grep | awk {'print $3'}
