ps aux | grep -w resource_discovery.py |grep -v grep | awk {'print $4'}
