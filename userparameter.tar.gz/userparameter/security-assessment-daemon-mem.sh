ps aux | grep -w assessment_daemon.py |grep -v grep | awk {'print $4'}
