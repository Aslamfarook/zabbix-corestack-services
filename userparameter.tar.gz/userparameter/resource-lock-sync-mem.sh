ps aux | grep -w resource_lock_sync |grep -v grep | awk {'print $4'}
