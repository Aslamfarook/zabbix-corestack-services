ps aux | grep -w resource_tag_sync |grep -v grep | awk {'print $3'}
