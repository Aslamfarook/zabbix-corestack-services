#!/bin/bash


# Connection validation
port=18083
host=localhost
timeout 3 bash -c "cat < /dev/null > /dev/tcp/$host/$port" 2>/dev/null
check=$?
echo "Connection status to $host:$port is $check" >> /var/tmp/.governance_service
if [ $check -eq 0 ]
then
connstat=1
else	
connstat=0
fi

# Log validation
#logstat1=grep -inr error /var/log/corestack/governance.log 2>/dev/null
#if [[ "$logstat1" == "" ]]
#then
#logstat=1
#echo "Detected NO errors in governance logs" >> /var/tmp/.governance_service
#else
#logstat=0
#echo "Detected errors in governance logs" >> /var/tmp/.governance_service
#fi	

# Service validation
pstat=`ps -ef|grep -i governance_service|grep -v grep`
if [[ "$pstat" != "" ]]
then
psstat=1
echo "governance Service is running" >> /var/tmp/.governance_service
else
psstat=0
echo "governance Service is not running" >> /var/tmp/.governance_service
fi

## Final validation
if [[ $connstat -eq 0 || $psstat -eq 0 ]]
then
echo 0
else
echo 1
fi
