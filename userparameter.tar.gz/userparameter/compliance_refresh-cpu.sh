ps aux | grep -w compliance_refresh.py |grep -v grep | awk {'print $3'}
