ps aux | grep -w compliance_crawler.py |grep -v grep | awk {'print $3'}
