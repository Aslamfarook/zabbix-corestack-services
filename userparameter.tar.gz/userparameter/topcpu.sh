#!/bin/bash
read service
kalai=$(ps -aux |fgrep $service |awk '{print $2 " " $12}')
#kalai=$(ps aux  | fgrep $service | grep -v grep |awk {'print $3 '})i
#kalai=$(ps aux | grep -w heat-stack |grep -v grep | awk {'print $3'})


#echo $kalai
test=$(echo "$kalai" |awk '{print $1}')
a=0;
c=0;
for i in $test
do
  kalai1=$(top -b -d 2 -n 1 |grep $i | awk '{print $9}')
#echo "$kalai1"
#b=$(echo $kalai1 $a | awk '{ printf "%i", $1 + $2 }')
b=$(echo $kalai1 $a | awk '{ printf $1 + $2 }')
c=$(echo $b $c | awk '{ printf $1 + $2 }')
done
echo $c
