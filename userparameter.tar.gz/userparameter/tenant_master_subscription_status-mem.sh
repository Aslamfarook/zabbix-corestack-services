ps aux | grep -w tenant_master_subscription_status.py |grep -v grep | awk {'print $4'}
