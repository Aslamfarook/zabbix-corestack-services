#!/bin/bash





# Service validation
pstat=`ps -ef|grep -i custom_workflow_manager.py|grep -v grep`
if [[ "$pstat" != "" ]]
then
psstat=1
echo "custom_workflow_manager daemon is running" >> /var/tmp/.custom_workflow_manager_check
else
psstat=0
echo "custom_workflow_manager daemon not running" >> /var/tmp/.custom_workflow_manager_check
fi

## Final validation
if [[ $psstat -eq 0 ]]
then
echo 0
else
echo 1
fi
