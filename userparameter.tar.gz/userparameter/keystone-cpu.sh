ps aux | grep -w keystone-all |grep -v grep | awk {'print $3'} | head -n 1
