ps aux | grep -w operation_assessment_daemon.py |grep -v grep | awk {'print $4'}
