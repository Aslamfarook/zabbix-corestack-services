#!/bin/bash
read service
kalai=$(ps -aux |fgrep $service |awk '{print $2 " " $12}')
test=$(echo "$kalai" |awk '{print $1}')
a=0.0;
c=0.0;
for i in $test
do
  kalai1=$(top -b -d 2 -n 1 |grep $i | awk '{print $10}')
#echo "$kalai1"
b=$(echo $kalai1 $a | awk '{ printf "%f", $1 + $2 }')
c=$(echo $b $c | awk '{ printf "%f", $1 + $2 }')
done
echo $c
