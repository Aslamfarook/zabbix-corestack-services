#!/bin/bash

# Log validation

#logstat1=`sed -nr '/.*(SMTPAuthenticationError).*/p' /var/log/corestack/tenant_master_subscription_status.log 2>/dev/null`

#logstat1=`sed -nr '/.*(error).*/p' /var/log/corestack/queue_poller.log 2>/dev/null`
#
#if [[ "$logstat1" == "" ]]
#
#then
#
#logstat=1
#
#echo "Detected NO errors in queue_poller logs" >> /var/tmp/.queue_poller_check
#
#else
#
#logstat=0
#
#echo "Detected errors in queue_poller logs" >> /var/tmp/.queue_poller_check
#
#fi



# Service validation

pstat=`ps -ef|grep -i queue_poller.py|grep -v grep`

if [[ "$pstat" != "" ]]

then

psstat=1

echo "queue_poller daemon is running" >> /var/tmp/.queue_poller_check

else

psstat=0

echo "queue_poller daemon not running" >> /var/tmp/.queue_poller_check

fi



## Final validation

if [[ $psstat -eq 0 ]]

then

echo 0

else

echo 1

fi
