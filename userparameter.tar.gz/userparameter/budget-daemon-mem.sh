ps aux | grep -w budget_daemon |grep -v grep | awk {'print $4'}
