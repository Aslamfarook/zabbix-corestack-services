#!/bin/bash
# Log validation
#logstat1=`sed -nr '/.*(SMTPAuthenticationError).*/p' /var/log/corestack/account_subscription_create.log 2>/dev/null`
#logstat2=`sed -nr '/.*(error).*/p' /var/log/corestack/account_subscription_create.log 2>/dev/null`
#if [[ "$logstat1" == "" ]]
#then
#logstat=1
#echo "Detected NO errors in zabbix_governance logs" >> /var/tmp/.zabbix_governance
#else
#logstat=0
#echo "Detected errors in zabbix_governance logs" >> /var/tmp/.zabbix_governance
#fi

# Service validation
pstat=`ps -ef|grep -i zabbix_governance.py|grep -v grep`
if [[ "$pstat" != "" ]]
then
psstat=1
echo "zabbix_governance daemon is running" >> /var/tmp/.zabbix_governance_check
else
psstat=0
echo "zabbix_governance daemon not running" >> /var/tmp/.zabbix_governancec_check
fi

## Final validation
if [[ $logstat -eq 0 || $psstat -eq 0 ]]
then
echo 0
else
echo 1
fi
