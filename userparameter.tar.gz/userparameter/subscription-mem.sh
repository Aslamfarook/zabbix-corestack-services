ps aux | grep -w subscription |grep -v grep | awk {'print $4'}
