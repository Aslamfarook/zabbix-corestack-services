#!/bin/bash
# Connection validation
port=18090
host=localhost
timeout 3 bash -c "cat < /dev/null > /dev/tcp/$host/$port" 2>/dev/null
#telnet $host $port
#timeout 3 bash -c cat < /dev/null > telnet localhost 18090 2>/dev/null
check=$?
echo "Connection status to $host:$port is $check" >> /var/tmp/.broker_check
if [ $check -eq 0 ]
then
connstat=1
else
connstat=0
fi

# Log validation
#logstat1=`sed -nr '/.*(SMTPAuthenticationError).*/p' /var/log/corestack/notification_service.log 2>/dev/null`
#logstat1=`sed -nr '/.*(Error).*/p' /var/log/corestack/servicenow_broker.log 2>/dev/null`
#logstat1=grep -inr error /var/log/corestack/servicenow_broker.log 2>/dev/null
#if [[ "$logstat1" == "" ]]
#then
#logstat=1
#echo "Detected NO errors in broker logs" >> /var/tmp/.broker_check
#else
#logstat=0
#echo "Detected errors in broker logs" >> /var/tmp/.broker_check
#fi	

# Service validation
pstat=`ps -ef|grep -i servicenow-broker|grep -v grep`
if [[ "$pstat" != "" ]]
then
psstat=1
echo "Broker Service is running" >> /var/tmp/.broker_check
else
psstat=0
echo "Broker Service is not running" >> /var/tmp/.broker_check
fi

## Final validation
#if [[ $connstat -eq 0 || $logstat -eq 0 || $psstat -eq 0 ]]
if [[ $connstat -eq 0 || $psstat -eq 0 ]]
then
echo 0
else
echo 1
fi
