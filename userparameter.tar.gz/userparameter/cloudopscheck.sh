#!/bin/bash




# Log validation
#logstat1=`sed -nr '/.*(SMTPAuthenticationError).*/p' /var/log/corestack/account_subscription_create.log 2>/dev/null`
#logstat1=`sed -nr '/.*(error).*/p' /var/log/corestack/cloudops.log 2>/dev/null`
#if [[ "$logstat1" == "" ]]
#then
#logstat=1
#echo "Detected NO errors in cloudops_daemon logs" >> /var/tmp/.cloudops_check
#else
#logstat=0
#echo "Detected errors in cloudops_daemon logs" >> /var/tmp/.cloudops_check
#fi

# Service validation
pstat=`ps -ef|grep -i cloudops_daemon.py|grep -v grep`
if [[ "$pstat" != "" ]]
then
psstat=1
echo "cloudops daemon is running" >> /var/tmp/.cloudops_check
else
psstat=0
echo "cloudops daemon not running" >> /var/tmp/.cloudops_check
fi

## Final validation
#if [[ $logstat -eq 0 || $psstat -eq 0 ]]
if [[ $psstat -eq 0 ]]
then
echo 0
else
echo 1
fi
