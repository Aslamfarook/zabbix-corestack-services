ps aux | grep -w governance_service |grep -v grep | awk {'print $3'}
