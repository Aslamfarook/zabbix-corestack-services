ps aux | grep -w heat-api-cloudwatch |grep -v grep | awk {'print $3'}
