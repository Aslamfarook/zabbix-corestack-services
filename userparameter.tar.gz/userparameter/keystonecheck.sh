#!/bin/bash


# Connection validation
port=5000
host=localhost
timeout 3 bash -c "cat < /dev/null > /dev/tcp/$host/$port" 2>/dev/null
check=$?
echo "Connection status to $host:$port is $check" >> /var/tmp/.keystone_check
if [ $check -eq 0 ]
then
connstat=1
else
connstat=0
fi

# Connection1 validation
port1=35357
host1=localhost
timeout 3 bash -c "cat < /dev/null > /dev/tcp/$host1/$port1 2>/dev/null"
check1=$?
echo "Connection status to $host1:$port1 is $check1" >> /var/tmp/.keystone_check
if [ $check1 -eq 0 ]
then
connstat1=1
else
connstat1=0
fi

# Log validation
#logstat1=`sed -nr '/.*(SMTPAuthenticationError).*/p' /var/log/corestack/notification_service.log 2>/dev/null`
#logstat1=`sed -nr '/.*(Error).*/p' /var/log/corestack/servicenow_broker.log 2>/dev/null`
#logstat1=grep -inr error /var/log/corestack/keystone.log 2>/dev/null
#if [[ "$logstat1" == "" ]]
#then
#logstat=1
#echo "Detected NO errors in keystone logs" >> /var/tmp/.keystone_check
#else
#logstat=0
#echo "Detected errors in keystone logs" >> /var/tmp/.keystone_check
#fi	

# Service validation
pstat=`ps -ef|grep -i keystone-all|grep -v grep`
if [[ "$pstat" != "" ]]
then
psstat=1
echo "keystone Service is running" >> /var/tmp/.keystone_check
else
psstat=0
echo "keystone Service is not running" >> /var/tmp/.keystone_check
fi

## Final validation
if [[ $connstat -eq 0 || $connstat1 -eq 0 || $psstat -eq 0 ]]
then
echo 0
else
echo 1
fi
