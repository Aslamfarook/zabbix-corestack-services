ps aux | grep -w keystone-all |grep -v grep | awk {'print $4'} | head -n 1
