ps aux | grep -w compliance_bot.py |grep -v grep | awk {'print $3'}
