#!/bin/bash

# Log validation

#logstat1=`sed -nr '/.*(SMTPAuthenticationError).*/p' /var/log/corestack/tenant_master_subscription_status.log 2>/dev/null`

#logstat1=`sed -nr '/.*(error).*/p' /var/log/corestack/request_updator.log 2>/dev/null`
#
#if [[ "$logstat1" == "" ]]
#
#then
#
#logstat=1
#
#echo "Detected NO errors in request_updator logs" >> /var/tmp/.request_updator_check
#
#else
#
#logstat=0
#
#echo "Detected errors in request_updator logs" >> /var/tmp/.request_updator_check
#
#fi



# Service validation

pstat=`ps -ef|grep -i request_updator.py|grep -v grep`

if [[ "$pstat" != "" ]]

then

psstat=1

echo "request_updator daemon is running" >> /var/tmp/.request_updator_check

else

psstat=0

echo "request_updator daemon not running" >> /var/tmp/.request_updator_check

fi



## Final validation

#if [[ $logstat -eq 0 || $psstat -eq 0 ]]
if [[ $psstat -eq 0 ]]

then

echo 0

else

echo 1

fi
