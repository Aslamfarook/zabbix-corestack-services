#!/bin/bash


# Connection validation
port=18092
host=localhost
timeout 3 bash -c "cat < /dev/null > /dev/tcp/$host/$port" 2>/dev/null
check=$?
echo "Connection status to $host:$port is $check" >> /var/tmp/.operations_governance_service_check
if [ $check -eq 0 ]
then
connstat=1
else
connstat=0
fi

# Log validation
#logstat1=`sed -nr '/.*(SMTPAuthenticationError).*/p' /var/log/corestack/notification_service.log 2>/dev/null`
#logstat1=`sed -nr '/.*(Error).*/p' /var/log/corestack/servicenow_broker.log 2>/dev/null`
#logstat1=grep -inr error /var/log/corestack/congress.log 2>/dev/null
#if [[ "$logstat1" == "" ]]
#then
#logstat=1
#echo "Detected NO errors in congress logs" >> /var/tmp/.congress_check
#else
#logstat=0
#echo "Detected errors in congress logs" >> /var/tmp/.congress_check
#fi	

# Service validation
pstat=`ps -ef|grep -i operations_governance_service|grep -v grep`
if [[ "$pstat" != "" ]]
then
psstat=1
echo "operations_governance_service is running" >> /var/tmp/.operations_governance_service_check
else
psstat=0
echo "operations_governance_service is not running" >> /var/tmp/.operations_governance_service_check
fi

## Final validation
#if [[ $connstat -eq 0 || $logstat -eq 0 || $psstat -eq 0 ]]
if [[ $connstat -eq 0 || $psstat -eq 0 ]]
then
echo 0
else
echo 1
fi
