#!/bin/bash




# Log validation
#logstat1=`sed -nr '/.*(SMTPAuthenticationError).*/p' /var/log/corestack/account_subscription_create.log 2>/dev/null`
#logstat1=`sed -nr '/.*(error).*/p' /var/log/corestack/cost_analytics.log 2>/dev/null`
#if [[ "$logstat1" == "" ]]
#then
#logstat=1
#echo "Detected NO errors in cost_analytics logs" >> /var/tmp/.cost_analytics_check
#else
#logstat=0
#echo "Detected errors in cost_analytics logs" >> /var/tmp/.cost_analytics_check
#fi

# Service validation
pstat=`ps -ef|grep -i cost_analytics_daemon.py|grep -v grep`
if [[ "$pstat" != "" ]]
then
psstat=1
echo "cost_analytics daemon is running" >> /var/tmp/.cost_analytics_check
else
psstat=0
echo "cost_analytics daemon not running" >> /var/tmp/.cost_analytics_check
fi

## Final validation
#if [[ $logstat -eq 0 || $psstat -eq 0 ]]
if [[ $psstat -eq 0 ]]
then
echo 0
else
echo 1
fi	
