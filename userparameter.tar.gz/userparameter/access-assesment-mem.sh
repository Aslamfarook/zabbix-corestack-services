ps aux | grep -w access_assessment_daemon.py |grep -v grep | awk {'print $4'}
