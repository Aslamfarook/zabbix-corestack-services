ps aux | grep -w congress-server |grep -v grep | awk {'print $4'}
