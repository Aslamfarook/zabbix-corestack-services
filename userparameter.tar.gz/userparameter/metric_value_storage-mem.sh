ps aux | grep -w metric_value_storage_daemon.py |grep -v grep | awk {'print $4'}
