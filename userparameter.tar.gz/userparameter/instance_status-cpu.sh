ps aux | grep -w instance_status_daemon.py |grep -v grep | awk {'print $3'}
