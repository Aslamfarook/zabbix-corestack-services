#!/bin/bash




# Log validation
#logstat1=`sed -nr '/.*(SMTPAuthenticationError).*/p' /var/log/corestack/account_subscription_create.log 2>/dev/null`
#logstat1=`sed -nr '/.*(error).*/p' /var/log/corestack/compliance_refresh_console.log 2>/dev/null`
#if [[ "$logstat1" == "" ]]
#then
#logstat=1
#echo "Detected NO errors in compliance_refresh logs" >> /var/tmp/.compliance_refresh_check
#else
#logstat=0
#echo "Detected errors in compliance_refresh logs" >> /var/tmp/.compliance_refresh_check
#fi

# Service validation
pstat=`ps -ef|grep -i compliance_refresh.py|grep -v grep`
if [[ "$pstat" != "" ]]
then
psstat=1
echo "compliance_refresh daemon is running" >> /var/tmp/.compliance_refresh_check
else
psstat=0
echo "compliance_refresh daemon not running" >> /var/tmp/.compliance_refresh_check
fi

## Final validation
#if [[ $logstat -eq 0 || $psstat -eq 0 ]]
if [[ $psstat -eq 0 ]]
then
echo 0
else
echo 1
fi	
