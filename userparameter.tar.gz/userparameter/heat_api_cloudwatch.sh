#!/bin/bash


# Connection validation
port=8003
host=localhost
timeout 3 bash -c "cat < /dev/null > /dev/tcp/$host/$port" 2>/dev/null
check=$?
echo "Connection status to $host:$port is $check" >> /var/tmp/.heat_api_cloudwatch_check
if [ $check -eq 0 ]
then
connstat=1
else
connstat=0
fi

# Log validation
#logstat1=grep -inr error /var/log/corestack/heat_api_cloudwatch.log 2>/dev/null
#if [[ "$logstat1" == "" ]]
#then
#logstat=1
#echo "Detected NO errors in Heat API cloudwatch logs" >> /var/tmp/.heat_api_cloudwatch_check
#else
#logstat=0
#echo "Detected errors in Heat API  cloudwatch" >> /var/tmp/.heat_api_cloudwatch_check
#fi	

# Service validation
pstat=`ps -ef|grep -i heat-api-cloudwatch|grep -v grep`
if [[ "$pstat" != "" ]]
then
psstat=1
echo "Heat API cloudwatch Service is running" >> /var/tmp/.heat_api_cloudwatch_check
else
psstat=0
echo "Heat API cloudwatch Service is not running" >> /var/tmp/.heat_api_cloudwatch_check
fi

## Final validation
#if [[ $connstat -eq 0 || $logstat -eq 0 || $psstat -eq 0 ]]
if [[ $connstat -eq 0 || $psstat -eq 0 ]]
then
echo 0
else
echo 1
fi
