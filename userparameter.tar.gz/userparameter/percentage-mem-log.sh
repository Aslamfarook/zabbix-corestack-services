ps aux --sort -rss | head -5 |awk {'print $4  $11 $12'}
