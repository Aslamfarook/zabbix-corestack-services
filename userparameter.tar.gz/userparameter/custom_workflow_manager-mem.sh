ps aux | grep -w custom_workflow_manager.py |grep -v grep | awk {'print $4'}
