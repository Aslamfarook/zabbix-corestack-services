ps aux --sort -rss | head -5 | awk {'print $3 $11 $12'}
