ps aux | grep -w resource_dashboard |grep -v grep | awk {'print $3'}
