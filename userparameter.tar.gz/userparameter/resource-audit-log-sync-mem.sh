ps aux | grep -w resource_audit_log_sync |grep -v grep | awk {'print $4'}
