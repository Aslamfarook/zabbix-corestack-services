ps aux | grep -w cost_analytics_daemon.py |grep -v grep | awk {'print $4'}
