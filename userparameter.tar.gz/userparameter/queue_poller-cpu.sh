ps aux | grep -w queue_poller.py |grep -v grep | awk {'print $3'} | head -n 1
